#include <stdio.h>
#include <pthread.h>
#include <stdlib.h> //
#include <string.h>


int calculate_ascii_sum(const char* str) {
    int sum = 0;
    while (*str) {
        sum += (int)(*str);
        str++;
    }
    return sum;
}


void* thread_function(void* arg) {
    char* name = (char*)arg;
    int* result = malloc(sizeof(int));
    if (result == NULL) {
        perror("malloc failed");
        pthread_exit(NULL);
    }
    *result = calculate_ascii_sum(name);
    pthread_exit(result);
}

void* comparison_thread_function(void* arg) {
    int* results = (int*)arg;

    if (results[0] == results[1] && results[1] == results[2]) {
        printf("Youreka\n");
    } else if (results[0] == results[1] || results[1] == results[2] || results[0] == results[2]) {
        printf("Miracle\n");
    } else {
        printf("Hasta la vista\n");
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[3];
    pthread_t comparison_thread;
    int* results[3];
    char* names[3] = {"Alice", "Bob", "Charlie"};


    for (int i = 0; i < 3; i++) {
        if (pthread_create(&threads[i], NULL, thread_function, (void*)names[i]) != 0) {
            perror("pthread_create failed");
            return 1;
        }
    }


    int comparison_data[3];
    for (int i = 0; i < 3; i++) {
        if (pthread_join(threads[i], (void**)&results[i]) != 0) {
            perror("pthread_join failed");
            return 1;
        }
        comparison_data[i] = *results[i];
        free(results[i]);
    }


    if (pthread_create(&comparison_thread, NULL, comparison_thread_function, (void*)comparison_data) != 0) {
        perror("pthread_create failed");
        return 1;
    }

    if (pthread_join(comparison_thread, NULL) != 0) {
        perror("pthread_join failed");
        return 1;
    }

    return 0;
}

