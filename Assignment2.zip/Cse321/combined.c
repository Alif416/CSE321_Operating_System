
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void sort_descending(int* array, int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = i + 1; j < size; j++) {
            if (array[i] < array[j]) {
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }
}

void print_odd_even(int* array, int size) {
    for (int i = 0; i < size; i++) {
        if (array[i] % 2 == 0) {
            printf("%d is even\n", array[i]);
        } else {
            printf("%d is odd\n", array[i]);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <numbers>\n", argv[0]);
        return 1;
    }

    int size = argc - 1;
    int *array = malloc(size * sizeof(int));
    if (array == NULL) {
        perror("malloc failed");
        return 1;
    }

    for (int i = 0; i < size; i++) {
        array[i] = atoi(argv[i + 1]);
    }

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        free(array);
        return 1;
    }

    if (pid == 0) {

        sort_descending(array, size);
        printf("Sorted array in descending order:\n");
        for (int i = 0; i < size; i++) {
            printf("%d ", array[i]);
        }
        printf("\n");
        free(array);
        exit(0);
    } else {

        wait(NULL);
        print_odd_even(array, size);
        free(array);
    }

    return 0;
}
