#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t a, b, c;
    int process_count = 0;

    a = fork();
    if (a < 0) {
        perror("fork failed");
        return 1;
    }

    if (a == 0) {

        process_count++;

        b = fork();
        if (b < 0) {
            perror("fork failed");
            return 1;
        }

        if (b == 0) {
            process_count++;


            c = fork();
            if (c < 0) {
                perror("fork failed");
                return 1;
            }

            if (c == 0) {

                process_count++;
                if (getpid() % 2 != 0) {

                    pid_t d = fork();
                    if (d < 0) {
                        perror("fork failed");
                        return 1;
                    }

                    if (d == 0) {
                        process_count++;
                        _exit(0);
                    }
                }
                _exit(0);
            }

            wait(NULL);
            _exit(0);
        }

        wait(NULL);
        _exit(0);
    }


    process_count++;
    wait(NULL);

    printf("Total number of processes created: %d\n", process_count);

    return 0;
}
