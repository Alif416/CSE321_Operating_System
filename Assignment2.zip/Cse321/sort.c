// sort.c
#include <stdio.h>
#include <stdlib.h>

void sort_descending(int* array, int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = i + 1; j < size; j++) {
            if (array[i] < array[j]) {
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <numbers>\n", argv[0]);
        return 1;
    }

    int size = argc - 1;
    int *array = malloc(size * sizeof(int));
    if (array == NULL) {
        perror("malloc failed");
        return 1;
    }

    for (int i = 0; i < size; i++) {
        array[i] = atoi(argv[i + 1]);
    }

    sort_descending(array, size);

    printf("Sorted array in descending order:\n");
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    free(array);
    return 0;
}
