#include <stdio.h>
struct items {
    int quantity;
    float unitPrice;
};

int main() {
    struct items paratha, vegetable, mineralWater;

    float totalCost;
    int numberOfPeople;

    printf("Quantity Of Paratha: ");
    scanf("%d", &paratha.quantity);
    printf("Unit Price: ");
    scanf("%f", &paratha.unitPrice);

    printf("Quantity Of Vegetables: ");
    scanf("%d", &vegetable.quantity);
    printf("Unit Price: ");
    scanf("%f", &vegetable.unitPrice);


    printf("Quantity Of Mineral Water: ");
    scanf("%d", &mineralWater.quantity);
    printf("Unit Price: ");
    scanf("%f", &mineralWater.unitPrice);


    printf("Number of People: ");
    scanf("%d", &numberOfPeople);

    totalCost = (paratha.quantity * paratha.unitPrice) +
                (vegetable.quantity * vegetable.unitPrice) +
                (mineralWater.quantity * mineralWater.unitPrice);

    float costPerPerson = totalCost / numberOfPeople;

    printf("Individual people will pay: %.2f tk\n", costPerPerson);

    return 0;
}

