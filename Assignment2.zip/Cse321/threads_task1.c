
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_THREADS 5


void* thread_function(void* arg) {
    int thread_number = *((int*)arg);

    printf("thread-%d running\n", thread_number);
    sleep(1);
    printf("thread-%d closed\n", thread_number);

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    int thread_numbers[NUM_THREADS];
    int i;

    for (i = 0; i < NUM_THREADS; i++) {
        thread_numbers[i] = i + 1;
        if (pthread_create(&threads[i], NULL, thread_function, (void*)&thread_numbers[i]) != 0) {
            perror("pthread_create failed");
            return 1;
        }

        if (pthread_join(threads[i], NULL) != 0) {
            perror("pthread_join failed");
            return 1;
        }
    }

    return 0;
}
