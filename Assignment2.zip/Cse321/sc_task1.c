#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STRING_LENGTH 100

int main(int argc, char *argv[]) {
    FILE *file;
    char filename[MAX_STRING_LENGTH];
    char input[MAX_STRING_LENGTH];

    if (argc != 2) {
        printf("Usage: %s <>\n", argv[0]);
        return 1;
    }

    strncpy(filename, argv[1], MAX_STRING_LENGTH - 1);
    filename[MAX_STRING_LENGTH - 1] = '\0';  // Ensure null-termination

    file = fopen(filename, "a");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    printf("Enter strings to write to the file. Enter \"-1\" to stop.\n");

    while (1) {
        printf("Enter a string: ");
        fgets(input, MAX_STRING_LENGTH, stdin);

        input[strcspn(input, "\n")] = '\0';

        if (strcmp(input, "-1") == 0) {
            break;
        }

        fprintf(file, "%s\n", input);
    }

    fclose(file);
    printf("Strings have been written to %s\n", filename);

    return 0;


}

