#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 10

void login_process(int pipe1[], int pipe2[]);
void otp_generator_process(int pipe1[], int pipe2[]);
void mail_process(int pipe2[]);

int main() {

    int pipe1[2];
    int pipe2[2];


    if (pipe(pipe1) == -1 || pipe(pipe2) == -1) {
        perror("pipe failed");
        exit(EXIT_FAILURE);
    }


    if (fork() == 0) {
        login_process(pipe1, pipe2);
        exit(0);
    } else {

        wait(NULL);
    }

    return 0;
}

void login_process(int pipe1[], int pipe2[]) {
    char workspace[BUFFER_SIZE];


    printf("Please enter the workspace name:\n");
    fgets(workspace, sizeof(workspace), stdin);
    workspace[strcspn(workspace, "\n")] = 0;


    if (strcmp(workspace, "cse321") != 0) {
        printf("Invalid workspace name\n");
        return;
    }


    write(pipe1[1], workspace, sizeof(workspace));
    printf("Workspace name sent to otp generator from log in: %s\n\n", workspace);


    if (fork() == 0) {
        otp_generator_process(pipe1, pipe2);
        exit(0);
    } else {

        wait(NULL);


        char otp_from_mail[BUFFER_SIZE];
        read(pipe2[0], otp_from_mail, sizeof(otp_from_mail));
        printf("Log in received OTP from mail: %s\n", otp_from_mail);


        char otp_from_generator[BUFFER_SIZE];
        read(pipe2[0], otp_from_generator, sizeof(otp_from_generator));
        printf("Log in received OTP from otp generator: %s\n", otp_from_generator);


        if (strcmp(otp_from_mail, otp_from_generator) == 0) {
            printf("OTP Verified\n");
        } else {
            printf("OTP Incorrect\n");
        }
    }
}

void otp_generator_process(int pipe1[], int pipe2[]) {
    char workspace[BUFFER_SIZE];


    read(pipe1[0], workspace, sizeof(workspace));
    printf("OTP generator received workspace name from log in: %s\n\n", workspace);


    sprintf(workspace, "%d", getpid());
    write(pipe2[1], workspace, sizeof(workspace));
    printf("OTP sent to log in from OTP generator: %s\n", workspace);


    write(pipe2[1], workspace, sizeof(workspace));
    printf("OTP sent to mail from OTP generator: %s\n\n", workspace);


    if (fork() == 0) {
        mail_process(pipe2);
        exit(0);
    } else {

        wait(NULL);
    }
}

void mail_process(int pipe2[]) {
    char otp[BUFFER_SIZE];


    read(pipe2[0], otp, sizeof(otp));
    printf("Mail received OTP from OTP generator: %s\n", otp);


    write(pipe2[1], otp, sizeof(otp));
    printf("OTP sent to log in from mail: %s\n\n", otp);
}
