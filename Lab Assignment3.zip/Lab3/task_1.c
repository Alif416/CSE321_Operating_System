#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

struct shared {
    char sel[100];
    int b;
};

int main() {
    int shmid;
    struct shared *shm_ptr;
    int pipe_fd[2];
    char buffer[100];


    shmid = shmget(IPC_PRIVATE, sizeof(struct shared), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(1);
    }


    shm_ptr = (struct shared *)shmat(shmid, NULL, 0);
    if (shm_ptr == (struct shared *)-1) {
        perror("shmat failed");
        exit(1);
    }


    if (pipe(pipe_fd) == -1) {
        perror("pipe failed");
        exit(1);
    }


    shm_ptr->b = 1000;


    printf("Provide Your Input from Given Options:\n");
    printf("1. Type a to Add Money\n");
    printf("2. Type w to Withdraw Money\n");
    printf("3. Type c to Check Balance\n");


    printf("Your selection: ");
    fgets(shm_ptr->sel, sizeof(shm_ptr->sel), stdin);
    shm_ptr->sel[strcspn(shm_ptr->sel, "\n")] = 0;


    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        exit(1);
    } else if (pid == 0) {
        close(pipe_fd[0]);


        if (strcmp(shm_ptr->sel, "a") == 0) {
            int amount;
            printf("Enter amount to add: ");
            scanf("%d", &amount);
            if (amount > 0) {
                shm_ptr->b += amount;
                printf("Added successfully. Updated balance: %d\n", shm_ptr->b);
            } else {
                printf("Adding failed, Invalid amount\n");
            }
        } else if (strcmp(shm_ptr->sel, "w") == 0) {
            int amount;
            printf("Enter amount to withdraw: ");
            scanf("%d", &amount);
            if (amount > 0 && amount <= shm_ptr->b) {
                shm_ptr->b -= amount;
                printf("Withdrawal successful. Updated balance: %d\n", shm_ptr->b);
            } else {
                printf("Withdrawal failed, Invalid amount\n");
            }
        } else if (strcmp(shm_ptr->sel, "c") == 0) {
            printf("Current balance: %d\n", shm_ptr->b);
        } else {
            printf("Invalid selection\n");
        }


        write(pipe_fd[1], "Thank you for using\n", 21);
        close(pipe_fd[1]);
        exit(0);
    } else {
        close(pipe_fd[1]);


        wait(NULL);


        read(pipe_fd[0], buffer, sizeof(buffer));
        printf("%s", buffer);
        close(pipe_fd[0]);


        shmdt(shm_ptr);
        shmctl(shmid, IPC_RMID, NULL);
    }

    return 0;
}
